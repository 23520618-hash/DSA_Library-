# 📖 ỨNG DỤNG TỪ ĐIỂN TIẾNG ANH - RADIX TRIE VISUALIZER

---

## 🌟 1. Giới thiệu tổng quan

Ứng dụng **Từ điển Tiếng Anh - Radix Trie Visualizer** là một phần mềm tra cứu từ vựng được xây dựng dựa trên cấu trúc dữ liệu **Radix Trie** (hay còn gọi là *Patricia Trie* hoặc *Compact Prefix Tree*).

Mục tiêu cốt lõi của dự án không chỉ dừng lại ở việc tạo ra một cuốn từ điển thông thường, mà còn là một **công cụ trực quan hóa thuật toán (Algorithm Visualizer)**. Điểm hạn chế của việc học Cấu trúc dữ liệu là tính trừu tượng của nó. Ứng dụng này sinh ra để giải quyết vấn đề đó: Mọi thao tác Thêm, Tìm, Xóa đều được vẽ đồ họa trực tiếp theo thời gian thực (Real-time Rendering).

Bạn sẽ nhìn thấy rõ cách các luồng dữ liệu chạy, cách một không gian bộ nhớ được tối ưu hóa bằng thuật toán cắt ghép tiền tố.

---

## 🧠 2. Cấu trúc dữ liệu Radix Trie là gì?

Khác với Trie tiêu chuẩn (Standard Trie) - nơi mỗi node chỉ lưu trữ đúng 1 ký tự, **Radix Trie** là một phiên bản tối ưu hóa không gian (Space-optimized Trie).
Trong Radix Trie, nếu một node chỉ có duy nhất một node con, chúng sẽ được **gộp (merge)** lại với nhau. Điều này tạo ra các node chứa một "chuỗi ký tự" thay vì một ký tự đơn lẻ.

**Lợi ích khi dùng Radix Trie cho Từ điển:**
- **Tiết kiệm RAM / Không gian lưu trữ:** Giảm đáng kể số lượng node trống không mang nhiều ý nghĩa.
- **Tốc độ tra cứu cực nhanh:** Thời gian tìm kiếm là **$O(K)$** (với $K$ là độ dài của từ cần tìm), hoàn toàn không phụ thuộc vào việc từ điển của bạn có 1.000 từ hay 1.000.000 từ.
- **Hỗ trợ gợi ý từ (Auto-complete) tốt:** Rất dễ dàng để quét các từ có chung tiền tố (Prefix).

---

## ✨ 3. Tính năng cốt lõi

### 🔹 3.1. Thêm mục từ (Insert & Path Compression)
- Cho phép người dùng nhập từ tiếng Anh và nghĩa tiếng Việt tương ứng.
- **Sự thay đổi dữ liệu:** Thuật toán tự động duyệt từ gốc, so sánh chuỗi để tìm ra "Tiền tố chung dài nhất" (Longest Common Prefix). Nếu phát hiện sự chênh lệch, node hiện tại sẽ lập tức **tách làm đôi (Split Node)**, một phần giữ lại làm cha chung, phần còn lại bị đẩy xuống làm node con, và nhánh mới được tạo ra. Toàn bộ quy trình này được diễn đạt bằng đồ họa Canvas.

### 🔹 3.2. Tìm kiếm (Search)
- Tra cứu nghĩa của từ trong tích tắc.
- **Sự thay đổi dữ liệu:** "Nhật ký thuật toán" ở thanh điều khiển bên trái sẽ báo cáo chi tiết thuật toán đang đi qua những node nào, nhánh nào để đến được kết quả.

### 🔹 3.3. Xóa mục từ (Delete / Lazy Deletion)
- Cơ chế xóa mục từ an toàn ra khỏi bộ nhớ.
- **Sự thay đổi dữ liệu:** Ứng dụng sử dụng quy trình **Xóa lười (Lazy Deletion)**. Thuật toán tìm đến node cần xóa và "gỡ bỏ đánh dấu" node đó là một từ vựng kết thúc. Bong bóng đồ họa sẽ lập tức chuyển màu (từ Đầy sang Rỗng) để biểu diễn việc từ này đã biến mất khỏi danh sách từ điển hợp lệ nhưng không làm gãy cấu trúc cây.

### 🔹 3.4. Trực quan hóa Giao diện (Visualization UI)
- **Khu vực tương tác (Left Panel):** Nhập liệu với form Text hiện đại. Bộ 3 nút điều khiển "**THÊM**", "**TÌM**" và "**XÓA**" màu sắc nét. Bảng nhật ký (Logs) thông minh biên dịch ngôn ngữ máy thành ngôn ngữ người: *"Tách node 'car' thành 'ca' và 'r'"*.
- **Khu vực Trực quan (Right Panel):** Tích hợp thuật toán Auto-Layout (tự động phân bổ lại vị trí Node). Mỗi khi một Node bị vỡ tách ra làm đôi, nhánh hình cây liên kết sẽ tự động xòe góc rộng hơn, nhường vị trí cho nhau để bong bóng chữ trên Canvas không bao giờ bị đè chèn lên nhau. Giao diện cây sẽ trở thành một hình tam giác phát triển ra chiều rộng cực kì đẹp mắt.

---

## 🚀 4. Hướng dẫn cài đặt và sử dụng

### 📋 4.1. Môi trường yêu cầu
- **Hệ điều hành:** Windows / macOS / Linux.
- **Ngôn ngữ:** Python 3.6 trở lên.
- **Thư viện:** Ứng dụng sử dụng 100% Core Python (thư viện `tkinter`, `math`), **Không cần cài đặt thêm bất kì pip package nào**.

### 💻 4.2. Cách khởi chạy
1. Tải toàn bộ mã nguồn về máy (hoặc dùng thư mục VS Code hiện tại).
2. Mở Terminal / PowerShell.
3. Di chuyển đến thư mục dự án và gõ lệnh:
   ```bash
   python radix_gui_beautiful.py
   ```

### 🎮 4.3. Kịch bản chạy thử (Demo Walkthrough)
Để hiểu rõ nhất sức mạnh của thuật toán, hãy tuần tự làm theo các bước sau trong ứng dụng:

* **Bước 1:** Nhập từ `tester` (nghĩa: *người kiểm thử*).
  -> *Kết quả:* Xuất hiện một node duy nhất chứa chữ `tester` (màu xanh).
* **Bước 2:** Nhập từ `test` (nghĩa: *bài kiểm tra*).
  -> *Kết quả:* Node `tester` vỡ ra! Chữ `test` trở thành node cha (màu xanh), và phần dư `er` bị đẩy xuống làm node con (màu xanh).
* **Bước 3:** Nhập từ `team` (nghĩa: *đội nhóm*).
  -> *Kết quả:* Node `test` vỡ lần 2! Phần chung `te-` được trích xuất làm gốc (màu xám - không có nghĩa). Nhánh bên dưới chia làm 2: `-st` và `-am`.
* **Bước 4:** Nhập từ `toast` (nghĩa: *bánh mì nướng*).
  -> *Kết quả:* Node gốc lớn `te-` lại vỡ, tách chữ `t-` làm đỉnh chóp bộ nhớ. Cây chia hai ngả: ngả chữ `-e` và ngả chữ `-oast`.

* **Bước 5:** Cuối cùng, gõ lại chữ `test` và nhấn nút "**TÌM**".
  -> *Kết quả:* Nhánh âm báo màu xanh xuất hiện ở hộp thoại báo "Đã tìm thấy!", còn mục log nháy báo: "Đi qua nhánh 'te-' -> nhánh 'st'".

*(Mọi thao tác Thêm / Tìm / Xóa đều được log cụ thể việc đi dọc các nhánh và hiển thị cực kỳ trực quan trên cửa sổ giao diện)*.

---

## 🎨 5. Cấu trúc Giao diện & Thiết kế

Khác với các ứng dụng mặc định thô cứng của Windows, thiết kế ứng dụng này mang phong cách **Minimalism (Tối giản)** với chế độ màn hình tối **Dark Mode**. Bảng màu được lấy cảm hứng từ chủ đề **Catppuccin** nổi tiếng của giới lập trình viên:

- `Xám Đen (#1E1E2E)`: Hình nền sâu, dịu mắt.
- `Trắng Ánh Kim (#CDD6F4)`: Màu văn bản sắc nét.
- `Xanh Pastel (#89B4FA)`: Màu chủ đạo của đường nối và nút bấm.
- `Xanh Lá Nhạt (#A6E3A1)`: Hiển thị trạng thái thành công, hoặc các Node mang dữ liệu đầy đủ (End of word).
- `Hồng Đỏ (#F38BA8)`: Báo lỗi và hành động Xóa.

---

## 📅 6. Hướng phát triển trong tương lai (To-Do)
- [ ] Tính năng gợi ý từ (Auto-complete khi gõ text).
- [ ] Gộp node (Merge node) hoàn chỉnh sau khi xóa (Tránh dư thừa node vô nghĩa).
- [ ] Lưu trữ và tải lại cây dữ liệu từ tệp `.json` hoặc `.txt`.
- [ ] Cải thiện thuật toán nhường khoảng cách (Layout Padding) để Canvas dàn trải đều hơn khi dữ liệu lớn hàng nghìn từ.

---

*Cảm ơn bạn đã sử dụng ứng dụng! Mọi tương tác trên cấu trúc dữ liệu đồ họa này đều nhằm mục đích giáo dục và nghiên cứu các hệ thống tối ưu bộ nhớ.*